import axios from 'axios'
import React, { useEffect, useState } from 'react'
import ProductCard from './ProductCard'
import "./Recommendation.css";

const Recommendaion = () => {
    let [rec, setRec]= useState([{}])
    async function getRec() {
        await axios({
          method: "GET",
          url:"http://localhost:5000/rec",
        })
        .then((response) => {
          // let res =response.data
          // setData(response.data.top_discounted_products)
          setRec(response.data)
          console.log(response.data)
         // setProfileData(({
           // profile_name: res.name,
            //about_me: res.about}))
            
        }).catch((error) => {
          if (error.response) {
            console.log(error.response)
            console.log(error.response.status)
            console.log(error.response.headers)
            }
        })}
      
      useEffect(() => {
      getRec()
    //   console.log(JSON.stringify(data))

                
      }, [rec]);

  return (
    <div class="Rec">
        
               {rec.map(product => (
          <ProductCard el={product}/>

        ))}
       
    </div>
  )
}

export default Recommendaion