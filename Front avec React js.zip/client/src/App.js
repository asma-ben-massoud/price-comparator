import './App.css';
import axios from 'axios';
import React, {useEffect, useState} from 'react';
import { Route, Routes } from "react-router-dom";
import AllProducts from './Pages/AllProducts';
import OneProduct from './Pages/OneProduct';
import Error from './Pages/Error';
import Navbar from './Components/Navbar';

function App() {
  

  return (
    <div className="App">
      <Navbar />
      <Routes>
        <Route exact path="/" element={<AllProducts />} />
        <Route path={`/product/:ref`} element={<OneProduct/>}/>
        {/* <Route path="/listEmp" element={<ListEmp />} /> */}
        {/* <Route path="/addEmp" element={<AddEmp />} /> */}
        {/* <Route path="/editEmp/:id" element={<EditEmp />} /> */}
        {/* <Route path="/taches/:id" element={<Taches />} /> */}
        <Route path="/*" element={<Error />} />
      </Routes>
    </div>
  );
}

export default App;
