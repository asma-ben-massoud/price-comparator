import axios from 'axios';
import React, { useState, useEffect } from 'react';
import ProductCard from './ProductCard';

const Filters = () => {
  const [products, setProducts] = useState([]);
  const [selectedBrand, setSelectedBrand] = useState('');
  const [selectedMemory, setSelectedMemory] = useState(''); 
  
  
  useEffect(() => {
    async function getDataFiltered() {
        const params = new URLSearchParams();

        if (selectedBrand) {
          params.append('Brand', selectedBrand);
        }

        if (selectedMemory) {
          params.append('Mémoire', selectedMemory);
        }

        const queryString = params.toString();

{        await axios({
          method: "GET",
          url:`http://127.0.0.1:5000/search?${queryString}`,
        })
        .then((response) => {
          // let res =response.data
          setProducts(response.data.products)
          console.log(response)
         // setProfileData(({
           // profile_name: res.name,
            //about_me: res.about}))
            
        }).catch((error) => {
          if (error.response) {
            console.log(error.response)
            console.log(error.response.status)
            console.log(error.response.headers)
            }
         
              })
        }}

    // Call the getDataFiltered function whenever Filters changes
    getDataFiltered();
  }, [selectedBrand, selectedMemory]);

  const handleMemoryChange = (event) => {
    setSelectedMemory(event.target.value);
  };

  const handleBrandChange = (event) => {
    setSelectedBrand(event.target.value);
  };

  return (
    <div>
        {/* Filter by brand */}
      <label>
        Brand:
        <select value={selectedBrand} onChange={handleBrandChange}>
          <option value="">Brands</option>
          <option value="Dell">Dell</option>
          <option value="Lenovo">Lenovo</option>
          <option value="Acer">Acer</option>
          <option value="Hp">Hp</option>
          <option value="Msi">Msi</option>
        </select>
      </label>

              {/* Filter by brand */}
              <label>
        Mémoire:
        <select value={selectedMemory} onChange={handleMemoryChange}>
          <option value="">Mémoire</option>
          <option value=" 4 Go"> 4 Go </option>
          <option value=" 8 Go "> 8 Go </option>
          <option value="16 Go"> 16 Go </option>
          <option value="20 Go"> 20 Go </option>
          <option value="24 Go"> 24 Go </option>
          <option value="32 Go"> 32 Go</option>
          
        </select>
      </label>

      {/* Display products */}
      {products ?
      <div >
        
        {products.map(product => (
          <ProductCard el={product}/>

        ))}
      </div> : <p>Selectionne tes filtres</p>}
    </div>
  )
}

export default Filters