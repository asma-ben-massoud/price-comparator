import React from 'react'
import "./ProductCard.css";
import { Link } from 'react-router-dom';


const ProductCard = ({el}) => {
  return (
<div class="product-card">
  <img src={el['Image URL']} alt="Product Name" class="product-image"/>
  <div class="product-info">
    <h5 class="product-name">{el.Name}</h5>
    <p class="product-description">Ref: {el.Ref}</p>
    <p class="product-description">Brand: {el.Brand}</p>
    <p class="product-description">Brand: {el.Store}</p>
    <div class="product-footer">
      <p class="product-price">{el.Price} TND</p>
      <p class="old-price">{el["Old Price"]} TND</p>
      <Link to={`/product/${el.Ref}`}>
                <button class="buy-button">Voir plus</button>
              </Link>
    </div>
  </div>
</div>


  )
}

export default ProductCard