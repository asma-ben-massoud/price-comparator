import axios from 'axios'
import React, { useEffect, useState } from 'react'
import ProductCard from '../Components/ProductCard'
import "./AllProducts.css";
import Filters from '../Components/Filters';
import Recommendaion from '../Components/Recommendaion';

const AllProducts = () => {
    let [data, setData]= useState([{}])
    async function getData() {
        await axios({
          method: "GET",
          url:"http://localhost:5000/products",
        })
        .then((response) => {
          // let res =response.data
          // setData(response.data.top_discounted_products)
          setData(response.data.products)
          //console.log(response)
         // setProfileData(({
           // profile_name: res.name,
            //about_me: res.about}))
            
        }).catch((error) => {
          if (error.response) {
            console.log(error.response)
            console.log(error.response.status)
            console.log(error.response.headers)
            }
        })}
      
      useEffect(() => {
      getData()
    //   console.log(JSON.stringify(data))
                
      }, [data]);
  return (
    <div>
      
      <h1>Les meilleures offres sur les ordinateurs portables</h1>
    <div class="listProd">
        
        {data.map((el) => (

<div key={el.Ref}>
  <ProductCard el={el} />
</div>
))}
</div>

<h1>Selectionner vos filtres</h1>
<Filters/>

<h1>Des recommendations pour vous</h1>
<Recommendaion/>

        </div>
  )
}

export default AllProducts