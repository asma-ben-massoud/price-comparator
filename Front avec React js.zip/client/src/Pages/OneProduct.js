import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Link, useParams } from "react-router-dom";
import "./OneProduct.css";
import ProductCard from '../Components/ProductCard';


const OneProduct = () => {
    let [item, setItem]= useState([{}])
    let [similar, setSimilar]= useState([{}])
    let [sameProd, setSameProd]= useState([{}])
    let [new_1, setNew_1] = useState([{}])
    let [new_2, setNew_2] = useState([{}])
    let [new_3, setNew_3] = useState([{}])
    let [new_4, setNew_4] = useState([{}])
    let [new_5, setNew_5] = useState([{}])
    let [same_1,setSame_1] = useState([{}])
    let [same_2,setSame_2] = useState([{}])

    
    const params = useParams();

    async function getItem(ref) {
        await axios({
          method: "GET",
          url:`http://localhost:5000/product/${ref}`,
        })
        .then((response) => {
          const res =response.data
          // console.log(res)
            setItem(res.product[0])
        }).catch((error) => {
          if (error.response) {
            console.log(error.response)
            console.log(error.response.status)
            console.log(error.response.headers)
            }
        })}

        // ***********
        async function getSameProducts(ref) {
          await axios({
            method: "GET",
            url:`http://localhost:5000/similair_product/${ref}`,
          })
          .then((response) => {
            const res =response.data
            // console.log(res.similar_products[0])
              setSameProd(res.similar_products)
              // console.log(similar)
          }).catch((error) => {
            if (error.response) {
              console.log(error.response)
              console.log(error.response.status)
              console.log(error.response.headers)
              }
          })}

          async function getSame_1(ref, array) {
            
            await axios({
               method: "GET",
               url:`http://localhost:5000/product/${array[0].product}`,
             })
             .then((response) => {
               const res =response.data
              //  console.log(res.product[0])
                 setSame_1(res.product[0])
             }).catch((error) => {
               if (error.response) {
                 console.log(error.response)
                 console.log(error.response.status)
                 console.log(error.response.headers)
                 }
             })}

             async function getSame_2(ref, array) {
            
              await axios({
                 method: "GET",
                 url:`http://localhost:5000/product/${array[1].product}`,
               })
               .then((response) => {
                 const res =response.data
                //  console.log(res.product[0])
                   setSame_2(res.product[0])
               }).catch((error) => {
                 if (error.response) {
                   console.log(error.response)
                   console.log(error.response.status)
                   console.log(error.response.headers)
                   }
               })}
        // *************


        async function getSimilar(ref) {
          await axios({
            method: "GET",
            url:`http://localhost:5000/compare/${ref}`,
          })
          .then((response) => {
            const res =response.data
            // console.log(res.similar_products[0])
              setSimilar(res)
              // console.log(similar)
          }).catch((error) => {
            if (error.response) {
              console.log(error.response)
              console.log(error.response.status)
              console.log(error.response.headers)
              }
          })}

          async function getNew_1(ref, array) {
            
           await axios({
              method: "GET",
              url:`http://localhost:5000/product/${array[0].product}`,
            })
            .then((response) => {
              const res =response.data
              console.log(res.product[0])
                setNew_1(res.product[0])
            }).catch((error) => {
              if (error.response) {
                console.log(error.response)
                console.log(error.response.status)
                console.log(error.response.headers)
                }
            })}

            async function getNew_2(ref, array) {
             
              await axios({
                method: "GET",
                url:`http://localhost:5000/product/${array[1].product}`,
              })
              .then((response) => {
                const res =response.data
                console.log(res.product[0])
                  setNew_2(res.product[0])
              }).catch((error) => {
                if (error.response) {
                  console.log(error.response)
                  console.log(error.response.status)
                  console.log(error.response.headers)
                  }
              })}
              async function getNew_3(ref, array) {
             
                await axios({
                  method: "GET",
                  url:`http://localhost:5000/product/${array[2].product}`,
                })
                .then((response) => {
                  const res =response.data
                  console.log(res.product[0])
                    setNew_3(res.product[0])
                }).catch((error) => {
                  if (error.response) {
                    console.log(error.response)
                    console.log(error.response.status)
                    console.log(error.response.headers)
                    }
                })}
                async function getNew_4(ref, array) {
             
                  await axios({
                    method: "GET",
                    url:`http://localhost:5000/product/${array[3].product}`,
                  })
                  .then((response) => {
                    const res =response.data
                    console.log(res.product[0])
                      setNew_4(res.product[0])
                  }).catch((error) => {
                    if (error.response) {
                      console.log(error.response)
                      console.log(error.response.status)
                      console.log(error.response.headers)
                      }
                  })}
                  async function getNew_5(ref, array) {
             
                    await axios({
                      method: "GET",
                      url:`http://localhost:5000/product/${array[4].product}`,
                    })
                    .then((response) => {
                      const res =response.data
                      console.log(res.product[0])
                        setNew_5(res.product[0])
                    }).catch((error) => {
                      if (error.response) {
                        console.log(error.response)
                        console.log(error.response.status)
                        console.log(error.response.headers)
                        }
                    })}

      useEffect(() => {
      
       getItem(params.ref)
       getSimilar(params.ref)
       
      getNew_1(params.ref,similar)
      getNew_2(params.ref,similar)
      getNew_3(params.ref,similar)
      getNew_4(params.ref,similar)
      getNew_5(params.ref,similar)
      // console.log(similar[0].product)
      getSame_1(params.ref,similar)
      getSame_2(params.ref,similar)
                
      }, [similar]);
  return (
 
    <div class="product-details">

<div class="product-image">
    <img src={item['Image URL']} alt="Product Image"/>
  </div>

  <div class="product-info">
    <h1 class="product-name">{item.Name}</h1>
    <p class="product-description">Ref: {item.Ref}</p>
    <p class="product-description">Brand: {item.Brand}</p>
    <p class="product-description">Store: {item.Store}</p>
    <p class="product-description">{item.Availability}</p>
    <p class="product-price">{item.Price} TND</p>
    <p class="old-price">{item['Old Price']} TND</p>
    <button class="buy-button"><a href={item.product_url} target="_blank" rel="noopener noreferrer">Consulter l'offre sur {item.Store}</a></button>
   
  </div>



  <div class="fiche-technique">
    <h2>La Fiche Technique</h2>
    <table class="technical-specs">
      <tr>
        <th>Feature</th>
        <th>Specification</th>
      </tr>
     
      <tr>
        <td>Système d'exploitation</td>
        <td>{item["Système d'exploitation"]}</td>
      </tr>
      <tr>
        <td>Type de Processeur</td>
        <td>{item['Type de Processeur']}</td>
      </tr>
      <tr>
        <td>Mémoire</td>
        <td>{item["Mémoire"]}</td>
      </tr>
      <tr>
        <td>Carte Graphique</td>
        <td>{item["Carte Graphique"]}</td>
      </tr>
      <tr>
        <td>Taille de l'écran</td>
        <td>{item["Taille de l'écran"]}</td>
      </tr>
      <tr>
        <td>Garantie</td>
        <td>{item["Garantie"]}</td>
      </tr>
      <tr>
        <td>Disque Dur</td>
        <td>{item["Disque Dur"]}</td>
      </tr>
      <tr>
        <td>Couleur</td>
        <td>{item["Couleur"]}</td>
      </tr>
      
      
    
    </table>
  </div>

 
  
  <div>
    <h3>Des produits similaires</h3>
    
<div >
{new_2 ? <ProductCard el={new_2} /> : ""}
  {new_1 ? <ProductCard el={new_1} /> : ""}
  {new_3 ? <ProductCard el={new_3} /> : ""}
  {new_4 ? <ProductCard el={new_4} /> : ""}
  {new_5 ? <ProductCard el={new_5} /> : ""}

</div>

  </div>

  <div>
    <h3>Meme produit</h3>
    
<div >
{same_2 ? <ProductCard el={new_2} /> : ""}
  {same_1 ? <ProductCard el={new_1} /> : ""}
  

</div>

  </div>
</div>



  )
}

export default OneProduct