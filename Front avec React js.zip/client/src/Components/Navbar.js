import React from "react";
import { Link } from "react-router-dom";
import "./Navbar.css";


const Navbar = () => {
  return (
    <div className="menu">
      <ul class="menu-bar">
        <Link to="/">
          <li
            style={{
              color: "#010515",
              fontFamily: " 'Pacifico', cursive",
              fontSize: "xx-large",
            }}
          >
            {" "}
            Home
          </li>
        </Link>

        <Link to="/">
          <li>Produits</li>
        </Link>
        
      </ul>
    </div>
  );
};

export default Navbar;
